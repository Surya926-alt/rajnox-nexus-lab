// NEXUS LAB Android wrapper. Versions mirror the NEXUS LAB app itself
// (AGP 9.1.0 / Gradle 9.3.1) so one JDK + Android SDK builds both.
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
    }
}

plugins {
    id("com.android.application") version "9.1.0" apply false
}

rootProject.name = "nexus_wrapper"
include(":app")
