package com.nexuslab.wrapper

import android.annotation.SuppressLint
import android.app.Activity
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Generated-app host. This is the ONLY code that runs inside an APK built
 * from a NEXUS LAB project: it loads the project bundled at
 * assets/www/<entry file> (written by WrapperProjectAssembler) into a
 * WebView and applies the handful of settings configured in AppConfig
 * (res/values/nexus_config.xml, generated per project — never edited by
 * hand). It does not talk to NEXUS LAB, does not depend on Flutter, and
 * has no network access beyond what the loaded page itself performs.
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val fullscreen = resources.getBoolean(R.bool.nexus_fullscreen)
        val showStatusBar = resources.getBoolean(R.bool.nexus_status_bar)
        val showNavigationBar = resources.getBoolean(R.bool.nexus_navigation_bar)
        val hasSplash = resources.getBoolean(R.bool.nexus_has_splash)
        val themeColor = try {
            resources.getColor(R.color.nexus_theme_color, theme)
        } catch (e: Exception) {
            Color.parseColor("#090B10")
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = themeColor
        window.navigationBarColor = themeColor
        applySystemBars(fullscreen, showStatusBar, showNavigationBar)

        val root = FrameLayout(this)
        root.setBackgroundColor(themeColor)
        setContentView(root)

        webView = buildWebView()
        root.addView(webView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        var splashView: ImageView? = null
        if (hasSplash) {
            splashView = buildSplashView(themeColor)
            if (splashView != null) {
                root.addView(splashView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                val splash = splashView ?: return
                val animation = getString(R.string.nexus_splash_animation)
                when (animation) {
                    "fade" -> splash.animate().alpha(0f).setDuration(260).withEndAction { root.removeView(splash) }.start()
                    "scale" -> {
                        splash.animate().scaleX(1.08f).scaleY(1.08f).alpha(0f).setDuration(260).withEndAction { root.removeView(splash) }.start()
                    }
                    else -> root.removeView(splash)
                }
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                // Only the main document failing is fatal to what the user sees;
                // a missing sub-resource (an optional image, say) should not
                // blank the whole page.
                if (request.isForMainFrame) {
                    Log.e("NexusWrapper", "Failed to load ${request.url}: ${error.description}")
                }
            }
        }

        val entryPath = getString(R.string.nexus_entry_path)
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/$entryPath")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWebView(): WebView {
        val view = WebView(this)
        val settings: WebSettings = view.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.allowFileAccessFromFileURLs = false
        settings.allowUniversalAccessFromFileURLs = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.mediaPlaybackRequiresUserGesture = false
        view.setBackgroundColor(Color.TRANSPARENT)

        // Serves assets/www/* at https://appassets.androidplatform.net/assets/www/*
        // instead of file:///android_asset/, so relative fetch()/XHR calls and
        // the project's own same-origin assumptions behave the same way they do
        // in a normal browser tab, and so no raw file:// scheme is ever exposed.
        val assetLoader = androidx.webkit.WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", androidx.webkit.WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        view.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)

            // Keep navigation inside the bundled project; this wrapper has no
            // address bar and is not a general-purpose browser.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = request.url.host
                return host != null && host != "appassets.androidplatform.net"
            }
        }
        return view
    }

    private fun buildSplashView(themeColor: Int): ImageView? {
        val resId = resources.getIdentifier("nexus_splash", "drawable", packageName)
        if (resId == 0) return null
        val image = ImageView(this)
        image.setImageResource(resId)
        image.scaleType = ImageView.ScaleType.CENTER_INSIDE
        image.setBackgroundColor(themeColor)
        return image
    }

    private fun applySystemBars(fullscreen: Boolean, showStatusBar: Boolean, showNavigationBar: Boolean) {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        val bars = mutableListOf<Int>()
        if (fullscreen || !showStatusBar) bars.add(WindowInsetsCompat.Type.statusBars())
        if (fullscreen || !showNavigationBar) bars.add(WindowInsetsCompat.Type.navigationBars())
        if (bars.isNotEmpty()) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            var mask = 0
            for (type in bars) mask = mask or type
            window.decorView.post { controller.hide(mask) }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Re-apply bar visibility: some OEM skins restore system bars on a
        // configuration change (rotation, dark-mode switch) despite the
        // transient-hide request above.
        val fullscreen = resources.getBoolean(R.bool.nexus_fullscreen)
        val showStatusBar = resources.getBoolean(R.bool.nexus_status_bar)
        val showNavigationBar = resources.getBoolean(R.bool.nexus_navigation_bar)
        applySystemBars(fullscreen, showStatusBar, showNavigationBar)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
