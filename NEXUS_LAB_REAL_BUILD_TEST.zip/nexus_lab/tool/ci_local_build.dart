import 'dart:io';

import 'package:nexus_lab/build/build_engine.dart';
import 'package:nexus_lab/build/build_models.dart';
import 'package:nexus_lab/build/local_build_engine.dart';
import 'package:nexus_lab/build/wrapper_template.dart';
import 'package:nexus_lab/models/project.dart';

Future<void> main() async {
  final root = Directory.current;
  final output = Directory('${root.path}/ci-output');
  await output.create(recursive: true);

  final project = Project(
    id: 'ci-smoke-test',
    name: 'NEXUS CI Smoke Test',
    description: 'Minimal HTML project used to exercise the real LocalBuildEngine.',
    entryFile: 'index.html',
    appConfig: AppConfig(
      appName: 'NEXUS CI Test',
      packageId: 'com.nexuslab.citest',
      versionName: '1.0.0',
      versionCode: 1,
      orientation: 'portrait',
    ),
    files: [
      ProjectFile(
        path: 'index.html',
        content: '''<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="style.css"></head>
<body><main><h1>NEXUS LAB</h1><p id="status">APK BUILD ENGINE WORKED</p><button onclick="document.getElementById('status').textContent='JS WORKED TOO'">TEST JS</button></main><script src="app.js"></script></body></html>''',
      ),
      ProjectFile(
        path: 'style.css',
        content: '''body{margin:0;min-height:100vh;display:grid;place-items:center;background:#060609;color:#fff;font-family:system-ui}main{text-align:center;padding:40px}button{padding:12px 18px;border-radius:12px;border:1px solid #7c3cff;background:#111;color:#fff}''',
      ),
      ProjectFile(
        path: 'app.js',
        content: '''console.log('NEXUS CI JS loaded');''',
      ),
    ],
  );

  final engine = LocalBuildEngine(
    template: DirectoryWrapperTemplateSource('${root.path}/android_wrapper_template'),
    defaultOutputDirectory: output.path,
    keepBuildDirectory: true,
    gradleTimeout: const Duration(minutes: 20),
  );

  final status = await engine.status();
  stdout.writeln('ENGINE AVAILABLE: ${status.available}');
  stdout.writeln('ENGINE DETAILS: ${status.details}');
  if (!status.available) {
    stderr.writeln(status.reason ?? 'Local build engine unavailable.');
    for (final item in status.missing) stderr.writeln('MISSING: $item');
    exitCode = 2;
    return;
  }

  final result = await engine.run(
    BuildRequest(project: project, mode: BuildMode.debug, outputDirectory: output.path),
    onEvent: (event) => stdout.writeln('[${event.stage.label}] ${event.message}'),
  );

  stdout.writeln('RESULT SUCCESS: ${result.success}');
  stdout.writeln('APK: ${result.artifactPath}');
  if (!result.success) {
    stderr.writeln('ERROR: ${result.error?.code.code}');
    stderr.writeln(result.error?.detail ?? 'Build failed');
    stderr.writeln(result.error?.technicalDetails ?? '');
    exitCode = 1;
    return;
  }

  final artifact = result.artifactPath == null ? null : File(result.artifactPath!);
  if (artifact == null || !await artifact.exists() || await artifact.length() == 0) {
    stderr.writeln('Engine reported success but the APK artifact is missing/empty.');
    exitCode = 1;
    return;
  }
  stdout.writeln('APK SIZE: ${await artifact.length()} bytes');
}
