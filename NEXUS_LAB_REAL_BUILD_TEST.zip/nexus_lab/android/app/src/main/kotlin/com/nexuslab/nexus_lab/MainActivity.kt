package com.nexuslab.nexus_lab

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream

/**
 * Backs lib/build/apk_actions.dart's `nexus_lab/apk_actions` channel: install
 * (hand the APK to the system package installer), share (system share
 * sheet), save (copy into the public Downloads collection) and
 * outputDirectory (a real, app-specific directory build engines can write
 * APKs into — dart:io's Directory.systemTemp is not reliable on Android).
 *
 * This activity performs the handoff only; it never claims an install
 * finished; only that the installer/share sheet was opened or that the file
 * was copied.
 */
class MainActivity : FlutterActivity() {
    private val channelName = "nexus_lab/apk_actions"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "outputDirectory" -> result.success(outputDirectory().absolutePath)
                "install" -> handleInstall(call.argument<String>("path"), result)
                "share" -> handleShare(call.argument<String>("path"), result)
                "save" -> handleSave(call.argument<String>("path"), result)
                else -> result.notImplemented()
            }
        }
    }

    /** App-specific external storage; no permission required, cleared on uninstall. */
    private fun outputDirectory(): File {
        val base = getExternalFilesDir(null) ?: filesDir
        val dir = File(base, "nexus_builds")
        dir.mkdirs()
        return dir
    }

    private fun apkFileFor(path: String?, result: MethodChannel.Result): File? {
        if (path.isNullOrEmpty()) {
            result.error("APK_NOT_FOUND", "No path was given.", null)
            return null
        }
        val file = File(path)
        if (!file.exists() || file.length() <= 0L) {
            result.error("APK_NOT_FOUND", "The APK file does not exist.", null)
            return null
        }
        return file
    }

    private fun contentUriFor(file: File): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

    private fun handleInstall(path: String?, result: MethodChannel.Result) {
        val file = apkFileFor(path, result) ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            val settingsIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(settingsIntent)
            } catch (e: Exception) {
                // Fall through; the error below still tells the caller what happened.
            }
            result.error("PERMISSION_ERROR", "Allow NEXUS LAB to install unknown apps, then try again.", null)
            return
        }
        try {
            val uri = contentUriFor(file)
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(uri, "application/vnd.android.package-archive")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (intent.resolveActivity(packageManager) == null) {
                result.error("UNKNOWN_BUILD_ERROR", "No package installer app was found to handle the APK.", null)
                return
            }
            startActivity(intent)
            result.success("The system installer was opened.")
        } catch (e: Exception) {
            result.error("UNKNOWN_BUILD_ERROR", "Could not open the installer: ${e.message}", null)
        }
    }

    private fun handleShare(path: String?, result: MethodChannel.Result) {
        val file = apkFileFor(path, result) ?: return
        try {
            val uri = contentUriFor(file)
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "application/vnd.android.package-archive"
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val chooser = Intent.createChooser(intent, "Share APK")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(chooser)
            result.success("The share sheet was opened.")
        } catch (e: Exception) {
            result.error("UNKNOWN_BUILD_ERROR", "Could not open the share sheet: ${e.message}", null)
        }
    }

    private fun handleSave(path: String?, result: MethodChannel.Result) {
        val file = apkFileFor(path, result) ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val resolver = contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("MediaStore did not return a destination.")
                resolver.openOutputStream(uri).use { out ->
                    if (out == null) throw IllegalStateException("Could not open the destination for writing.")
                    FileInputStream(file).use { input -> input.copyTo(out) }
                }
                result.success("Saved to Downloads as ${file.name}.")
            } else {
                // Pre-scoped-storage fallback (API < 29). Requires
                // WRITE_EXTERNAL_STORAGE, which is only declared for these API
                // levels (see AndroidManifest.xml, maxSdkVersion="28").
                if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    result.error("PERMISSION_ERROR", "Storage permission is required to save on this Android version.", null)
                    return
                }
                val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                downloads.mkdirs()
                val destination = File(downloads, file.name)
                FileInputStream(file).use { input -> destination.outputStream().use { out -> input.copyTo(out) } }
                result.success("Saved to ${destination.absolutePath}.")
            }
        } catch (e: Exception) {
            result.error("UNKNOWN_BUILD_ERROR", "Could not save the APK: ${e.message}", null)
        }
    }
}
