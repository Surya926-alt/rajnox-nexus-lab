# NEXUS LAB remote build contract (v1, draft)

No server implements this today. `RemoteBuildEngine` (`lib/build/remote_build_engine.dart`)
is written against this contract through the `RemoteBuildTransport` interface; plugging in a
real implementation of that interface is the only thing needed to make the engine available.
Nothing here is backed by a fake server.

## Flow

1. **Probe** — `GET /capabilities` → `{ canBuildHtmlApk, canBuildAndroid, canSignRelease: false, serviceName, contractVersion: 1 }`.
   Release signing is **not** defined in v1 (no channel exists to hand a server your signing
   secrets); `RemoteBuildEngine` refuses release builds itself and never calls submit for one.
2. **Submit** — upload the `BuildBundle` (deterministic file list + bytes, see
   `BuildBundle.manifest()`) and the `AppConfig` JSON for a `debug` build. Server returns a
   `buildId`.
3. **Stream** — server streams newline-delimited `BuildEvent` JSON objects (see
   `BuildEvent.toJson()` / `BuildEvent.tryParseLine()`) ending in exactly one terminal stage
   (`success`, `failed`, `cancelled`, or `unavailable`).
4. **Fetch** — on a `success` terminal event, the client downloads the APK bytes and
   independently re-validates them with `ApkValidator` before ever reporting success — the
   server's own "success" claim is never trusted on its own.
5. **Cancel** — `POST /builds/{id}/cancel`.

## Why debug-only for now

Release builds need a private key. There is no secure way to hand a signing password to a
remote service from this client without a much larger secrets-management design (short-lived
signing tokens, server-side HSM, etc.). Rather than inventing that, v1 simply refuses: build
release APKs locally (`LocalBuildEngine`), or extend this contract deliberately later.
