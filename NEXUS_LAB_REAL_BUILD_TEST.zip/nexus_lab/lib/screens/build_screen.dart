import 'package:flutter/material.dart';
import 'package:nexus_lab/build/apk_actions.dart';
import 'package:nexus_lab/build/build_controller.dart';
import 'package:nexus_lab/build/build_engine.dart';
import 'package:nexus_lab/models/project.dart';

const _bg = Color(0xFF090B10);
const _panel = Color(0xFF11141B);
const _line = Color(0xFF252B38);
const _violet = Color(0xFF8B7CFF);
const _cyan = Color(0xFF54D6FF);
const _amber = Color(0xFFFFC14D);
const _red = Color(0xFFFF6B6B);

/// Build provider selection, preflight, live build log, progress and result,
/// and install/share/save for the produced APK. Everything shown here comes
/// from [BuildController] / [BuildEngine]: no step, percentage or log line is
/// invented by this screen.
class BuildScreen extends StatefulWidget {
  const BuildScreen({super.key, required this.project, required this.registry, this.onRecord});

  final Project project;
  final BuildEngineRegistry registry;
  final void Function(BuildRecord record)? onRecord;

  @override
  State<BuildScreen> createState() => _BuildScreenState();
}

class _BuildScreenState extends State<BuildScreen> {
  late final BuildController _controller;
  final _apkActions = ApkActions();
  final _keystorePathController = TextEditingController();
  final _keyAliasController = TextEditingController();
  final _scrollController = ScrollController();
  ApkActionOutcome? _lastActionOutcome;

  @override
  void initState() {
    super.initState();
    _controller = BuildController(project: widget.project, registry: widget.registry, onRecord: widget.onRecord);
    _controller.addListener(_onChange);
    _initOutputDirectory();
  }

  Future<void> _initOutputDirectory() async {
    // On Android, dart:io's default temp path is not reliable; ask the
    // platform for a real app-specific directory before refreshing engines.
    await _apkActions.outputDirectory();
    await _controller.refresh();
  }

  void _onChange() {
    if (!mounted) return;
    setState(() {});
    if (_controller.events.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!_scrollController.hasClients) return;
        _scrollController.animateTo(_scrollController.position.maxScrollExtent, duration: const Duration(milliseconds: 150), curve: Curves.easeOut);
      });
    }
  }

  @override
  void dispose() {
    _controller.removeListener(_onChange);
    _controller.dispose();
    _keystorePathController.dispose();
    _keyAliasController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _updateSigning() {
    final path = _keystorePathController.text.trim();
    final alias = _keyAliasController.text.trim();
    _controller.setSigning(path.isEmpty || alias.isEmpty ? null : SigningConfig(keystorePath: path, keyAlias: alias));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        title: const Text('BUILD APK', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2)),
        actions: [
          IconButton(onPressed: _controller.running ? null : () => _controller.refresh(), tooltip: 'Re-check build environment', icon: const Icon(Icons.refresh)),
        ],
      ),
      body: SafeArea(
        child: _controller.loading && _controller.statuses.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _enginePicker(),
                  const SizedBox(height: 14),
                  _modeAndSigning(),
                  const SizedBox(height: 14),
                  _preflightCard(),
                  const SizedBox(height: 14),
                  _actionsRow(),
                  const SizedBox(height: 14),
                  if (_controller.events.isNotEmpty) _logCard(),
                  const SizedBox(height: 14),
                  if (_controller.result != null) _resultCard(_controller.result!),
                ],
              ),
      ),
    );
  }

  Widget _card(Widget child) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: _line)),
        child: child,
      );

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(text, style: const TextStyle(fontSize: 11, letterSpacing: 1.2, color: Colors.white60, fontWeight: FontWeight.bold)),
      );

  Widget _enginePicker() => _card(Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('BUILD PROVIDER'),
          for (final engine in widget.registry.engines)
            _EngineTile(
              engine: engine,
              status: _controller.statuses[engine.id],
              selected: _controller.selectedEngineId == engine.id,
              enabled: !_controller.running,
              onTap: () => _controller.selectEngine(engine.id),
            ),
        ],
      ));

  Widget _modeAndSigning() => _card(Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('BUILD MODE'),
          SegmentedButton<BuildMode>(
            segments: const [
              ButtonSegment(value: BuildMode.debug, label: Text('DEBUG')),
              ButtonSegment(value: BuildMode.release, label: Text('RELEASE')),
            ],
            selected: {_controller.mode},
            onSelectionChanged: _controller.running ? null : (s) => _controller.setMode(s.first),
          ),
          if (_controller.mode == BuildMode.release) ...[
            const SizedBox(height: 12),
            const Text('Release builds are signed with an external keystore. Passwords are never entered here: set NEXUS_KEYSTORE_PASSWORD and NEXUS_KEY_PASSWORD as environment variables on the machine running the build.', style: TextStyle(color: Colors.white54, fontSize: 12)),
            const SizedBox(height: 10),
            TextField(controller: _keystorePathController, enabled: !_controller.running, onChanged: (_) => _updateSigning(), decoration: const InputDecoration(labelText: 'Keystore path', hintText: '/path/to/release.jks')),
            const SizedBox(height: 8),
            TextField(controller: _keyAliasController, enabled: !_controller.running, onChanged: (_) => _updateSigning(), decoration: const InputDecoration(labelText: 'Key alias')),
          ],
        ],
      ));

  Widget _preflightCard() {
    final report = _controller.report;
    if (report == null) return const SizedBox.shrink();
    return _card(Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle('BUILD PREFLIGHT'),
        for (final check in report.checks) _checkRow(check),
      ],
    ));
  }

  Widget _checkRow(BuildCheck check) {
    final color = check.passed ? _cyan : (check.isWarning ? _amber : _red);
    final icon = check.passed ? Icons.check_circle_outline : (check.isWarning ? Icons.warning_amber_rounded : Icons.error_outline);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(check.label, style: const TextStyle(color: Colors.white70, fontSize: 13)),
                if (check.detail != null) Text(check.detail!, style: TextStyle(color: color.withValues(alpha: .85), fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionsRow() {
    final canStart = _controller.canStart;
    return Row(
      children: [
        Expanded(
          child: FilledButton.icon(
            onPressed: canStart ? () => _controller.start() : null,
            icon: const Icon(Icons.build_circle_outlined),
            label: Text(_controller.running ? 'BUILDING…' : 'BUILD ${_controller.mode.name.toUpperCase()} APK'),
          ),
        ),
        if (_controller.running) ...[
          const SizedBox(width: 10),
          OutlinedButton(onPressed: () => _controller.cancel(), child: const Text('CANCEL')),
        ],
      ],
    );
  }

  Widget _logCard() {
    final events = _controller.events;
    return _card(SizedBox(
      height: 220,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle('BUILD LOG'),
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: events.length,
              itemBuilder: (context, i) {
                final event = events[i];
                final color = event.level == BuildEventLevel.error ? _red : (event.level == BuildEventLevel.warning ? _amber : Colors.white70);
                return Text('[${event.stage.label}] ${event.message}', style: TextStyle(fontFamily: 'monospace', fontSize: 11.5, color: color));
              },
            ),
          ),
        ],
      ),
    ));
  }

  Widget _resultCard(BuildResult result) {
    if (result.success) {
      return _card(Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(children: [Icon(Icons.check_circle, color: _cyan), SizedBox(width: 8), Text('APK READY', style: TextStyle(color: _cyan, fontWeight: FontWeight.bold))]),
          const SizedBox(height: 8),
          Text(result.outputPath ?? '', style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Colors.white70)),
          if (result.fileSize != null) Text(_formatBytes(result.fileSize!), style: const TextStyle(color: Colors.white54, fontSize: 12)),
          if (result.metadata != null) ...[
            const SizedBox(height: 6),
            Text(
              'package ${result.metadata!.packageName ?? '?'} · v${result.metadata!.versionName ?? '?'} (${result.metadata!.versionCode ?? '?'}) · metadata via ${result.metadata!.source}'
              '${result.metadata!.signatureVerified == null ? '' : result.metadata!.signatureVerified! ? ' · signature verified' : ' · signature NOT verified'}',
              style: const TextStyle(color: Colors.white54, fontSize: 11),
            ),
          ],
          for (final warning in result.warnings) Padding(padding: const EdgeInsets.only(top: 4), child: Text('⚠ $warning', style: const TextStyle(color: _amber, fontSize: 11))),
          const SizedBox(height: 12),
          if (_apkActions.isSupported) _apkActionButtons(result.outputPath!) else const Text('Install / Share / Save are only available on Android.', style: TextStyle(color: Colors.white38, fontSize: 11)),
          if (_lastActionOutcome != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_lastActionOutcome!.message, style: TextStyle(color: _lastActionOutcome!.ok ? _cyan : _red, fontSize: 12))),
        ],
      ));
    }
    final error = result.error;
    return _card(Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [const Icon(Icons.error_outline, color: _red), const SizedBox(width: 8), Expanded(child: Text(error?.title ?? 'BUILD FAILED', style: const TextStyle(color: _red, fontWeight: FontWeight.bold)))]),
        if (error?.detail != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error!.detail!, style: const TextStyle(color: Colors.white70))),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(error.remedy, style: const TextStyle(color: Colors.white54, fontSize: 12))),
        if (error?.technicalDetails != null) ...[
          const SizedBox(height: 8),
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: const Text('Technical details', style: TextStyle(color: Colors.white54, fontSize: 12)),
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: _bg, borderRadius: BorderRadius.circular(8)),
                child: SelectableText(error!.technicalDetails!, style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.white60)),
              ),
            ],
          ),
        ],
      ],
    ));
  }

  Widget _apkActionButtons(String path) => Wrap(
        spacing: 8,
        children: [
          OutlinedButton.icon(onPressed: () => _runAction(ApkAction.install, path), icon: const Icon(Icons.install_mobile, size: 16), label: const Text('INSTALL')),
          OutlinedButton.icon(onPressed: () => _runAction(ApkAction.share, path), icon: const Icon(Icons.share, size: 16), label: const Text('SHARE')),
          OutlinedButton.icon(onPressed: () => _runAction(ApkAction.save, path), icon: const Icon(Icons.save_alt, size: 16), label: const Text('SAVE')),
        ],
      );

  Future<void> _runAction(ApkAction action, String path) async {
    final outcome = await _apkActions.perform(action, path);
    if (!mounted) return;
    setState(() => _lastActionOutcome = outcome);
  }

  static String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB';
  }
}

class _EngineTile extends StatelessWidget {
  const _EngineTile({required this.engine, required this.status, required this.selected, required this.enabled, required this.onTap});

  final BuildEngine engine;
  final BuildEngineStatus? status;
  final bool selected;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final available = status?.available ?? false;
    return InkWell(
      onTap: enabled ? onTap : null,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: selected ? _violet.withValues(alpha: .12) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: selected ? _violet : _line),
        ),
        child: Row(
          children: [
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_unchecked, size: 18, color: selected ? _violet : Colors.white38),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(status?.displayName ?? engine.displayName, style: const TextStyle(color: Colors.white, fontSize: 13)),
                  Text(
                    available ? 'Available' : (status?.reason ?? 'Checking…'),
                    style: TextStyle(color: available ? _cyan : Colors.white38, fontSize: 11),
                  ),
                ],
              ),
            ),
            Icon(available ? Icons.check_circle : Icons.block, size: 16, color: available ? _cyan : Colors.white24),
          ],
        ),
      ),
    );
  }
}
