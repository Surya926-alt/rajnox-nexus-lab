class ProcessEvent {
  const ProcessEvent(this.type, {this.data = ''});
  final String type;
  final String data;
}

abstract class ExecutionProvider {
  String get id;
  String get status;
  Stream<ProcessEvent> execute(String command, String cwd);
  Future<void> cancel();
}

class UnavailableExecutionProvider implements ExecutionProvider {
  @override String get id => 'unavailable';
  @override String get status => 'NOT CONNECTED';
  @override Stream<ProcessEvent> execute(String command, String cwd) async* {
    yield const ProcessEvent('started');
    yield const ProcessEvent('failed', data: 'Terminal provider unavailable. This build supports project editing and web preview; connect an execution provider to run system commands.');
  }
  @override Future<void> cancel() async {}
}
