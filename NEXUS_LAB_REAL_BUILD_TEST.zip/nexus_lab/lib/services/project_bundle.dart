import 'dart:convert';
import 'package:nexus_lab/models/project.dart';

class ProjectBundle {
  const ProjectBundle({required this.html, required this.entryFile});
  final String html;
  final String entryFile;
}

class ProjectBundleResolver {
  ProjectBundle? resolve(Project project) {
    String? entry = project.entryFile;
    if (entry == null) {
      for (final f in project.files) {
        if (f.extension == 'html') { entry = f.path; break; }
      }
    }
    if (entry == null) return null;
    final entryFile = project.fileAt(entry);
    if (entryFile == null) return null;
    var html = entryFile.content;
    final base = _directory(entry);
    html = html.replaceAllMapped(RegExp(r'''<link\b([^>]*?)\bhref=["']([^"']+)["']([^>]*)>''', caseSensitive: false), (m) {
      final path = _normalize(base, m[2]!);
      final file = project.fileAt(path);
      return file?.extension == 'css' ? '<style data-nexus-source="$path">${file!.content}</style>' : m.group(0)!;
    });
    html = html.replaceAllMapped(RegExp(r'''<script\b([^>]*?)\bsrc=["']([^"']+)["']([^>]*)></script>''', caseSensitive: false), (m) {
      final path = _normalize(base, m[2]!);
      final file = project.fileAt(path);
      return file?.extension == 'js' ? '<script data-nexus-source="$path">${file!.content}</script>' : m.group(0)!;
    });
    html = html.replaceAllMapped(RegExp(r'''(<(?:img|source|video|audio)\b[^>]*\bsrc=["'])([^"']+)(["'])''', caseSensitive: false), (m) {
      final file = project.fileAt(_normalize(base, m[2]!));
      return file == null ? m.group(0)! : '${m[1]}${_dataUri(file)}${m[3]}';
    });
    return ProjectBundle(html: html, entryFile: entry);
  }
  String _directory(String path) => path.contains('/') ? path.substring(0, path.lastIndexOf('/')) : '';
  String _normalize(String base, String reference) {
    if (reference.startsWith('http://') || reference.startsWith('https://') || reference.startsWith('data:') || reference.startsWith('#') || reference.startsWith('/')) return reference;
    final result = <String>[];
    for (final part in <String>[if (base.isNotEmpty) ...base.split('/'), ...reference.split('/')]) {
      if (part.isEmpty || part == '.') continue;
      if (part == '..' && result.isNotEmpty) { result.removeLast(); } else if (part != '..') result.add(part);
    }
    return result.join('/');
  }
  String _dataUri(ProjectFile file) {
    if (file.content.startsWith('data:')) return file.content;
    final mime = ProjectFile.mimeForExtension(file.extension);
    // Binary files carry base64 already; text files are UTF-8 encoded first.
    return 'data:$mime;base64,${base64Encode(file.bytes)}';
  }
}
