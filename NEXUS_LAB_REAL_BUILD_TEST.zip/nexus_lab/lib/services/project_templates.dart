import 'package:nexus_lab/models/project.dart';

class ProjectTemplates {
  static Project create(String type, {String? name}) {
    final projectName = name?.trim().isNotEmpty == true ? name!.trim() : 'web-playground';
    final files = switch (type) {
      'blank' => [ProjectFile(path: 'index.html', content: '<!doctype html>\n<html><body><h1>New project</h1></body></html>')],
      'multi-page' => [ProjectFile(path: 'index.html', content: _index), ProjectFile(path: 'about.html', content: '<!doctype html>\n<html><body><h1>About</h1><a href="index.html">Home</a></body></html>'), ProjectFile(path: 'style.css', content: _css)],
      _ => [ProjectFile(path: 'index.html', content: _index), ProjectFile(path: 'style.css', content: _css), ProjectFile(path: 'script.js', content: _js)],
    };
    return Project(id: '${DateTime.now().microsecondsSinceEpoch}', name: projectName, files: files, templateType: type);
  }
  static const _index = '<!doctype html>\n<html>\n<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>NEXUS Preview</title><link rel="stylesheet" href="style.css"></head>\n<body><main><span>NEXUS LAB</span><h1>Build something remarkable.</h1><p>Your local web project is ready.</p><button onclick="hello()">RUN ACTION</button></main><script src="script.js"></script></body>\n</html>';
  static const _css = ':root{font-family:system-ui;color:#f6f7fb;background:#090b10}body{margin:0;min-height:100vh;display:grid;place-items:center}main{width:min(520px,80vw);padding:42px;border:1px solid #3a3c68;border-radius:24px;background:#11141b}span{color:#54d6ff;letter-spacing:.2em}h1{font-size:42px}button{padding:13px 18px;border:0;border-radius:10px;color:white;background:#6f62e8}';
  static const _js = 'function hello(){console.log("Action executed inside the live lab");document.querySelector("button").textContent="SUCCESS";}';
}
