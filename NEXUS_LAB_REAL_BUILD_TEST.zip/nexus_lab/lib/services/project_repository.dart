import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:nexus_lab/models/project.dart';

class ProjectStorage {
  static const key = 'nexus.projects.v2';
  Future<Map<String, Project>> read() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null || raw.isEmpty) return {};
    try { final decoded = jsonDecode(raw); if (decoded is! Map) return {}; return decoded.map<String, Project>((id, value) => MapEntry(id.toString(), Project.fromJson((value as Map).cast<String, dynamic>()))); } catch (_) { return {}; }
  }
  Future<void> write(Map<String, Project> projects) async { final prefs = await SharedPreferences.getInstance(); if (!await prefs.setString(key, jsonEncode(projects.map((id, p) => MapEntry(id, p.toJson()))))) throw StateError('Project storage rejected the save.'); }
}

class ProjectRepository {
  ProjectRepository(this.storage);
  final ProjectStorage storage;
  Map<String, Project> _projects = {};
  bool _initialized = false;
  Future<void> initialize() async { if (!_initialized) { _projects = await storage.read(); _initialized = true; } }
  Future<List<Project>> listProjects() async { await initialize(); return _sorted; }
  List<Project> get _sorted => _projects.values.toList()..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  Future<Project?> loadProject(String id) async { await initialize(); return _projects[id]; }
  Future<void> saveProject(Project project) async { await initialize(); project.updatedAt = DateTime.now(); _projects[project.id] = project; await storage.write(_projects); }
  Future<void> createProject(Project project) async { await initialize(); if (_projects.values.any((p) => p.name.toLowerCase() == project.name.toLowerCase())) throw StateError('A project named ${project.name} already exists.'); await saveProject(project); }
  Future<void> deleteProject(String id) async { await initialize(); if (!_projects.containsKey(id)) throw StateError('Project not found.'); _projects.remove(id); await storage.write(_projects); }
  Future<void> renameProject(Project project, String name) async { await initialize(); final clean = name.trim(); if (clean.isEmpty) throw ArgumentError('Project name is required.'); if (_projects.values.any((p) => p.id != project.id && p.name.toLowerCase() == clean.toLowerCase())) throw StateError('A project with that name already exists.'); project.name = clean; project.appConfig.appName = clean; await saveProject(project); }
  Future<Project> duplicateProject(Project source) async { await initialize(); var name = '${source.name} copy'; var n = 2; while (_projects.values.any((p) => p.name.toLowerCase() == name.toLowerCase())) name = '${source.name} copy ${n++}'; final copy = Project(id: '${DateTime.now().microsecondsSinceEpoch}', name: name, description: source.description, files: source.files.map((f) => f.copyWith(id: '${DateTime.now().microsecondsSinceEpoch}-${f.path}')).toList(), templateType: source.templateType, entryFile: source.entryFile, appConfig: AppConfig.fromJson(source.appConfig.toJson())); await createProject(copy); return copy; }
}

class SettingsService {
  Future<bool> get onboardingComplete async => (await SharedPreferences.getInstance()).getBool('onboarding.complete') ?? false;
  Future<void> setOnboardingComplete(bool value) async => (await SharedPreferences.getInstance()).setBool('onboarding.complete', value);
  Future<int> get fontSize async => (await SharedPreferences.getInstance()).getInt('editor.fontSize') ?? 13;
  Future<void> setFontSize(int value) async => (await SharedPreferences.getInstance()).setInt('editor.fontSize', value);
  Future<bool> get autoRun async => (await SharedPreferences.getInstance()).getBool('preview.autoRun') ?? false;
  Future<void> setAutoRun(bool value) async => (await SharedPreferences.getInstance()).setBool('preview.autoRun', value);
  Future<bool> get autoSave async => (await SharedPreferences.getInstance()).getBool('editor.autoSave') ?? true;
  Future<void> setAutoSave(bool value) async => (await SharedPreferences.getInstance()).setBool('editor.autoSave', value);
}
