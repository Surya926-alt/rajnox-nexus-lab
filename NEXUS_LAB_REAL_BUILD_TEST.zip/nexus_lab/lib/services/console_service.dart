enum ConsoleLevel { log, info, warn, error, system }
class ConsoleEntry { const ConsoleEntry({required this.level, required this.message, this.timestamp, this.source}); final ConsoleLevel level; final String message; final DateTime? timestamp; final String? source; }
class ConsoleService {
  ConsoleService({this.maxEntries = 200});
  final int maxEntries;
  final List<ConsoleEntry> _entries = [];
  List<ConsoleEntry> get entries => List.unmodifiable(_entries);
  void add(ConsoleEntry entry) { _entries.add(entry); if (_entries.length > maxEntries) _entries.removeRange(0, _entries.length - maxEntries); }
  void clear() => _entries.clear();
}
