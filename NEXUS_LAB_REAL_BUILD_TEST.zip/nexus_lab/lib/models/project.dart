import 'dart:convert';
import 'dart:typed_data';

/// A single file inside a NEXUS LAB project.
///
/// Text files keep their source in [content] (encoding `utf8`). Binary files
/// (icons, images, fonts, audio) keep their bytes base64-encoded in [content]
/// with encoding `base64`. For backwards compatibility with V2/V2.1 projects a
/// text-typed file whose content is a `data:...;base64,` URI and whose
/// extension is a known binary type is also treated as binary.
class ProjectFile {
  ProjectFile({
    required this.path,
    required this.content,
    String? id,
    DateTime? updatedAt,
    this.encoding = utf8Encoding,
  })  : id = id ?? path,
        updatedAt = updatedAt ?? DateTime.now();

  static const utf8Encoding = 'utf8';
  static const base64Encoding = 'base64';

  static const _binaryExtensions = <String>{
    'png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'bmp', 'avif',
    'woff', 'woff2', 'ttf', 'otf',
    'mp3', 'ogg', 'wav', 'm4a', 'mp4', 'webm',
    'pdf', 'wasm',
  };

  static final _dataUriPrefix = RegExp(
    r'^\s*data:[^;,]*(?:;[^;,]*)*;base64,',
    caseSensitive: false,
  );

  final String id;
  String path;
  String content;
  DateTime updatedAt;
  final String encoding;

  String get name => path.split('/').last;
  String get extension => name.contains('.') ? name.split('.').last.toLowerCase() : '';

  /// True when [content] is base64 of the real file bytes.
  bool get isBinary => encoding == base64Encoding;

  /// True when this file's real payload is binary (explicitly base64, or a
  /// legacy pasted data URI on a binary extension).
  bool get hasBinaryPayload => isBinary || _embeddedDataUriBytes() != null;

  /// The exact bytes that must be shipped for this file.
  ///
  /// Throws [FormatException] when a binary file's base64 is corrupt.
  Uint8List get bytes {
    if (isBinary) return base64Decode(base64.normalize(content.replaceAll(RegExp(r'\s'), '')));
    final embedded = _embeddedDataUriBytes();
    if (embedded != null) return embedded;
    return Uint8List.fromList(utf8.encode(content));
  }

  Uint8List? _embeddedDataUriBytes() {
    if (!_binaryExtensions.contains(extension)) return null;
    final match = _dataUriPrefix.firstMatch(content);
    if (match == null) return null;
    try {
      final payload = content.substring(match.end).replaceAll(RegExp(r'\s'), '');
      return base64Decode(base64.normalize(payload));
    } on FormatException {
      return null;
    }
  }

  static String mimeForExtension(String extension) {
    switch (extension.toLowerCase()) {
      case 'html':
      case 'htm':
        return 'text/html';
      case 'css':
        return 'text/css';
      case 'js':
      case 'mjs':
        return 'text/javascript';
      case 'json':
        return 'application/json';
      case 'svg':
        return 'image/svg+xml';
      case 'png':
        return 'image/png';
      case 'jpg':
      case 'jpeg':
        return 'image/jpeg';
      case 'gif':
        return 'image/gif';
      case 'webp':
        return 'image/webp';
      case 'ico':
        return 'image/x-icon';
      case 'woff':
        return 'font/woff';
      case 'woff2':
        return 'font/woff2';
      case 'ttf':
        return 'font/ttf';
      case 'otf':
        return 'font/otf';
      case 'mp3':
        return 'audio/mpeg';
      case 'ogg':
        return 'audio/ogg';
      case 'wav':
        return 'audio/wav';
      case 'mp4':
        return 'video/mp4';
      case 'webm':
        return 'video/webm';
      case 'wasm':
        return 'application/wasm';
      default:
        return 'text/plain';
    }
  }

  ProjectFile copyWith({String? id, String? path, String? content, DateTime? updatedAt, String? encoding}) => ProjectFile(
        id: id ?? this.id,
        path: path ?? this.path,
        content: content ?? this.content,
        updatedAt: updatedAt ?? this.updatedAt,
        encoding: encoding ?? this.encoding,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'path': path,
        'content': content,
        'updatedAt': updatedAt.toIso8601String(),
        if (encoding != utf8Encoding) 'encoding': encoding,
      };

  factory ProjectFile.fromJson(Map<String, dynamic> json) => ProjectFile(
        id: json['id'] as String?,
        path: json['path'] as String,
        content: json['content'] as String? ?? '',
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? ''),
        encoding: json['encoding'] as String? ?? utf8Encoding,
      );
}

/// User-editable Android application configuration for the WebView wrapper.
class AppConfig {
  AppConfig({
    this.appName = '',
    this.packageId = 'com.example.nexusapp',
    this.versionName = '1.0.0',
    this.versionCode = 1,
    this.iconPath,
    this.splashPath,
    this.splashAnimation = 'none',
    this.orientation = 'portrait',
    this.fullscreen = false,
    this.statusBar = true,
    this.navigationBar = true,
    this.themeColor = defaultThemeColor,
    List<String>? permissions,
  }) : permissions = permissions ?? [];

  static const defaultThemeColor = '#090B10';

  String appName;
  String packageId;
  String versionName;
  int versionCode;
  String? iconPath;
  String? splashPath;
  String splashAnimation;
  String orientation;
  bool fullscreen;
  bool statusBar;
  bool navigationBar;
  String themeColor;
  List<String> permissions;

  AppConfig copy() => AppConfig.fromJson(toJson());

  Map<String, dynamic> toJson() => {
        'appName': appName,
        'packageId': packageId,
        'versionName': versionName,
        'versionCode': versionCode,
        'iconPath': iconPath,
        'splashPath': splashPath,
        'splashAnimation': splashAnimation,
        'orientation': orientation,
        'fullscreen': fullscreen,
        'statusBar': statusBar,
        'navigationBar': navigationBar,
        'themeColor': themeColor,
        'permissions': permissions,
      };

  factory AppConfig.fromJson(Map<String, dynamic> json) => AppConfig(
        appName: json['appName'] as String? ?? '',
        packageId: json['packageId'] as String? ?? 'com.example.nexusapp',
        versionName: json['versionName'] as String? ?? '1.0.0',
        versionCode: (json['versionCode'] as num?)?.toInt() ?? 1,
        iconPath: json['iconPath'] as String?,
        splashPath: json['splashPath'] as String?,
        splashAnimation: json['splashAnimation'] as String? ?? 'none',
        orientation: json['orientation'] as String? ?? 'portrait',
        fullscreen: json['fullscreen'] as bool? ?? false,
        statusBar: json['statusBar'] as bool? ?? true,
        navigationBar: json['navigationBar'] as bool? ?? true,
        themeColor: json['themeColor'] as String? ?? defaultThemeColor,
        permissions: (json['permissions'] as List<dynamic>? ?? []).whereType<String>().toList(),
      );
}

/// One entry in a project's build history. Only real engine results are stored.
class BuildRecord {
  BuildRecord({
    required this.status,
    required this.target,
    required this.startedAt,
    this.completedAt,
    this.outputPath,
    this.fileSize,
    List<String> logs = const [],
    String? id,
    this.mode = 'debug',
    this.engineId,
    this.packageId,
    this.versionName,
    this.versionCode,
    this.errorCode,
    this.errorSummary,
  })  : id = id ?? '${startedAt.microsecondsSinceEpoch}',
        logs = _capLogs(logs);

  /// History is stored inside the project JSON, so it is bounded.
  static const maxLogLines = 300;

  final String id;

  /// One of: success, failed, cancelled, unavailable (legacy: unknown).
  final String status;
  final String target;
  final DateTime startedAt;
  final DateTime? completedAt;
  final String? outputPath;
  final int? fileSize;
  final List<String> logs;
  final String mode;
  final String? engineId;
  final String? packageId;
  final String? versionName;
  final int? versionCode;
  final String? errorCode;
  final String? errorSummary;

  bool get succeeded => status == 'success';
  Duration? get duration => completedAt?.difference(startedAt);

  static List<String> _capLogs(List<String> logs) =>
      logs.length <= maxLogLines ? List<String>.unmodifiable(logs) : List<String>.unmodifiable(logs.sublist(logs.length - maxLogLines));

  Map<String, dynamic> toJson() => {
        'id': id,
        'status': status,
        'target': target,
        'startedAt': startedAt.toIso8601String(),
        'completedAt': completedAt?.toIso8601String(),
        'outputPath': outputPath,
        'fileSize': fileSize,
        'logs': logs,
        'mode': mode,
        'engineId': engineId,
        'packageId': packageId,
        'versionName': versionName,
        'versionCode': versionCode,
        'errorCode': errorCode,
        'errorSummary': errorSummary,
      };

  factory BuildRecord.fromJson(Map<String, dynamic> json) => BuildRecord(
        id: json['id'] as String?,
        status: json['status'] as String? ?? 'unknown',
        target: json['target'] as String? ?? 'unknown',
        startedAt: DateTime.tryParse(json['startedAt'] as String? ?? '') ?? DateTime.now(),
        completedAt: DateTime.tryParse(json['completedAt'] as String? ?? ''),
        outputPath: json['outputPath'] as String?,
        fileSize: (json['fileSize'] as num?)?.toInt(),
        logs: (json['logs'] as List<dynamic>? ?? []).whereType<String>().toList(),
        mode: json['mode'] as String? ?? 'debug',
        engineId: json['engineId'] as String?,
        packageId: json['packageId'] as String?,
        versionName: json['versionName'] as String?,
        versionCode: (json['versionCode'] as num?)?.toInt(),
        errorCode: json['errorCode'] as String?,
        errorSummary: json['errorSummary'] as String?,
      );
}

class Project {
  Project({
    required this.id,
    required this.name,
    required this.files,
    this.description = '',
    DateTime? createdAt,
    DateTime? updatedAt,
    this.templateType = 'html',
    String? entryFile,
    AppConfig? appConfig,
    List<BuildRecord>? buildHistory,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now(),
        entryFile = entryFile ?? _firstHtml(files),
        appConfig = appConfig ?? AppConfig(appName: name),
        buildHistory = buildHistory ?? [];

  static const maxBuildHistory = 10;

  final String id;
  String name;
  String description;
  DateTime createdAt;
  DateTime updatedAt;
  final List<ProjectFile> files;
  String templateType;
  String? entryFile;
  AppConfig appConfig;
  List<BuildRecord> buildHistory;

  int get fileCount => files.length;

  ProjectFile? fileAt(String path) {
    for (final file in files) {
      if (file.path == path) return file;
    }
    return null;
  }

  /// Newest first; bounded so project JSON stays small.
  void addBuildRecord(BuildRecord record) {
    buildHistory = [record, ...buildHistory];
    if (buildHistory.length > maxBuildHistory) {
      buildHistory = buildHistory.sublist(0, maxBuildHistory);
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'files': files.map((f) => f.toJson()).toList(),
        'templateType': templateType,
        'entryFile': entryFile,
        'appConfig': appConfig.toJson(),
        'buildHistory': buildHistory.map((b) => b.toJson()).toList(),
      };

  String encode() => jsonEncode(toJson());

  factory Project.fromJson(Map<String, dynamic> json) => Project(
        id: json['id'] as String,
        name: json['name'] as String,
        description: json['description'] as String? ?? '',
        createdAt: DateTime.tryParse(json['createdAt'] as String? ?? ''),
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? ''),
        files: (json['files'] as List<dynamic>? ?? [])
            .whereType<Map>()
            .map((f) => ProjectFile.fromJson(f.cast<String, dynamic>()))
            .toList(),
        templateType: json['templateType'] as String? ?? 'html',
        entryFile: json['entryFile'] as String?,
        appConfig: AppConfig.fromJson((json['appConfig'] as Map? ?? {}).cast<String, dynamic>()),
        buildHistory: (json['buildHistory'] as List<dynamic>? ?? [])
            .whereType<Map>()
            .map((b) => BuildRecord.fromJson(b.cast<String, dynamic>()))
            .toList(),
      );

  static String? _firstHtml(List<ProjectFile> files) {
    for (final file in files) {
      if (file.extension == 'html') return file.path;
    }
    return null;
  }
}
