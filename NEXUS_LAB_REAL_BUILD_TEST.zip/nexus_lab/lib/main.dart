import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:nexus_lab/models/project.dart';
import 'package:nexus_lab/services/project_bundle.dart';
import 'package:nexus_lab/services/project_repository.dart';
import 'package:nexus_lab/services/project_templates.dart';
import 'package:nexus_lab/execution/execution_provider.dart';
import 'package:nexus_lab/build/build_controller.dart';
import 'package:nexus_lab/build/apk_actions.dart';
import 'package:nexus_lab/services/console_service.dart';
import 'package:nexus_lab/screens/build_screen.dart';

const _bg = Color(0xFF090B10), _panel = Color(0xFF11141B), _panel2 = Color(0xFF171B24), _line = Color(0xFF252B38), _violet = Color(0xFF8B7CFF), _cyan = Color(0xFF54D6FF);

void main() {
  FlutterError.onError = (details) => FlutterError.dumpErrorToConsole(details);
  PlatformDispatcher.instance.onError = (error, stack) { debugPrint('$error\n$stack'); return true; };
  runApp(const NexusLabApp());
}

class NexusLabApp extends StatelessWidget {
  const NexusLabApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(debugShowCheckedModeBanner: false, title: 'NEXUS LAB', theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: _bg, colorScheme: ColorScheme.fromSeed(seedColor: _violet, brightness: Brightness.dark), useMaterial3: true), home: const NexusShell());
}

enum AppDestination { workspace, terminal, files, projects, tools, monitor, settings }
enum PreviewState { idle, loading, ready, error }

class NexusShell extends StatefulWidget {
  const NexusShell({super.key});
  @override State<NexusShell> createState() => _NexusShellState();
}

class _NexusShellState extends State<NexusShell> {
  final _repo = ProjectRepository(ProjectStorage());
  final _settings = SettingsService();
  final _search = TextEditingController();
  final _command = TextEditingController();
  final _console = <String>[];
  final _terminal = <String>['NEXUS LAB terminal ready.', 'Terminal provider unavailable.'];
  final _editors = <String, TextEditingController>{};
  final _appNameController = TextEditingController();
  final _packageController = TextEditingController();
  Timer? _autosaveTimer;
  Timer? _autorunTimer;
  AppDestination _destination = AppDestination.workspace;
  Project? _project;
  ProjectFile? _activeFile;
  bool _loading = true, _dirty = false, _autoSave = true, _autoRun = false;
  int _previewRevision = 0;
  String? _bootError;
  int _workspaceTab = 0, _fontSize = 13;

  @override void initState() { super.initState(); _boot(); }
  Future<void> _boot() async {
    try {
      _fontSize = await _settings.fontSize;
      _autoSave = await _settings.autoSave;
      _autoRun = await _settings.autoRun;
      var projects = await _repo.listProjects();
      if (projects.isEmpty) { final project = ProjectTemplates.create('html'); await _repo.createProject(project); projects = [project]; }
      final project = projects.first;
      if (!mounted) return;
      _appNameController.text = project.appConfig.appName;
      _packageController.text = project.appConfig.packageId;
      setState(() { _project = project; _activeFile = project.files.first; _loading = false; });
    } catch (error) { if (mounted) setState(() { _bootError = 'Project storage could not be opened: $error'; _loading = false; }); }
  }
  @override void dispose() { _autosaveTimer?.cancel(); _autorunTimer?.cancel(); for (final c in _editors.values) c.dispose(); _appNameController.dispose(); _packageController.dispose(); _search.dispose(); _command.dispose(); super.dispose(); }
  TextEditingController _controllerFor(ProjectFile file) => _editors.putIfAbsent(file.id, () { final c = TextEditingController(text: file.content); c.addListener(() { if (c.text != file.content && mounted) { setState(() { file.content = c.text; file.updatedAt = DateTime.now(); _dirty = true; }); _scheduleAutosave(); } }); return c; });
  void _scheduleAutosave() { _autosaveTimer?.cancel(); if (!_autoSave) return; _autosaveTimer = Timer(const Duration(milliseconds: 700), _save); if (_autoRun) { _autorunTimer?.cancel(); _autorunTimer = Timer(const Duration(milliseconds: 900), _run); } }
  Future<void> _save() async { final project = _project; if (project == null || !_dirty) return; try { await _repo.saveProject(project); if (mounted) setState(() { _dirty = false; _console.insert(0, 'SYSTEM  ${_activeFile?.name ?? 'project'} saved locally'); }); } catch (error) { _message('Save failed: $error'); } }
  Future<void> _run() async { if (_dirty) await _save(); if (mounted) setState(() { _previewRevision++; _workspaceTab = 1; }); }
  void _selectFile(ProjectFile file) { setState(() { _activeFile = file; _workspaceTab = 0; }); _controllerFor(file); }
  Future<void> _newFile() async { final project = _project; if (project == null) return; final name = await _textDialog('Create file', 'file.html'); if (name == null || name.trim().isEmpty) return; if (project.fileAt(name.trim()) != null) { _message('A file with that name already exists.'); return; } final file = ProjectFile(path: name.trim(), content: ''); project.files.add(file); _activeFile = file; _dirty = true; await _save(); setState(() {}); }
  Future<void> _renameFile(ProjectFile file) async { final project = _project; if (project == null) return; final name = await _textDialog('Rename file', file.path, initial: file.path); if (name == null || name.trim().isEmpty || name == file.path) return; if (project.fileAt(name.trim()) != null) { _message('A file with that name already exists.'); return; } file.path = name.trim(); await _save(); setState(() {}); }
  Future<void> _deleteFile(ProjectFile file) async { final project = _project; if (project == null || project.files.length == 1) { _message('A project must keep at least one file.'); return; } final ok = await _confirm('Delete ${file.name}?'); if (!ok) return; project.files.remove(file); if (_activeFile == file) _activeFile = project.files.first; await _save(); setState(() {}); }
  Future<void> _newProject() async { final type = await showModalBottomSheet<String>(context: context, backgroundColor: _panel, builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [for (final t in {'html':'HTML Starter','blank':'Blank Project','multi-page':'Multi-page Web'}.entries) ListTile(title: Text(t.value), onTap: () => Navigator.pop(context, t.key))]))); if (type == null) return; final name = await _textDialog('Project name', 'web-playground'); if (name == null || name.trim().isEmpty) return; try { final p = ProjectTemplates.create(type, name: name); await _repo.createProject(p); _appNameController.text = p.appConfig.appName; _packageController.text = p.appConfig.packageId; setState(() { _project = p; _activeFile = p.files.first; _destination = AppDestination.workspace; _dirty = false; }); } catch (e) { _message('$e'); } }
  Future<void> _switchProject(Project p) async { _appNameController.text = p.appConfig.appName; _packageController.text = p.appConfig.packageId; setState(() { _project = p; _activeFile = p.files.first; _destination = AppDestination.workspace; _dirty = false; }); }
  Future<void> _renameProject(Project project) async { final name = await _textDialog('Rename project', project.name, initial: project.name); if (name == null || name.trim().isEmpty) return; try { await _repo.renameProject(project, name); if (mounted) setState(() {}); } catch (error) { _message('$error'); } }
  Future<void> _duplicateProject(Project project) async { try { final copy = await _repo.duplicateProject(project); await _switchProject(copy); } catch (error) { _message('$error'); } }
  Future<void> _deleteProject(Project project) async { if (!await _confirm('Delete project ${project.name}?')) return; try { await _repo.deleteProject(project.id); final remaining = await _repo.listProjects(); if (remaining.isEmpty) { final replacement = ProjectTemplates.create('html'); await _repo.createProject(replacement); await _switchProject(replacement); } else { await _switchProject(remaining.first); } } catch (error) { _message('$error'); } }
  Future<void> _buildApk() async {
    final project = _project;
    if (project == null) return;
    if (_dirty) await _save();
    // dart:io's default temp directory is not reliable on Android; ask the
    // platform for a real app-specific directory before engines run.
    final outputDir = await ApkActions().outputDirectory();
    final registry = BuildEngineRegistry.defaults(outputDirectory: outputDir);
    if (!mounted) return;
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => BuildScreen(
        project: project,
        registry: registry,
        onRecord: (record) {
          project.addBuildRecord(record);
          unawaited(_repo.saveProject(project));
        },
      ),
    ));
  }
  Future<String?> _textDialog(String title, String hint, {String? initial}) async { final c = TextEditingController(text: initial); return showDialog<String>(context: context, builder: (_) => AlertDialog(title: Text(title), content: TextField(controller: c, autofocus: true, decoration: InputDecoration(hintText: hint)), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(context, c.text), child: const Text('CREATE'))])); }
  Future<bool> _confirm(String text) async => await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Confirm'), content: Text(text), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('CANCEL')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('DELETE'))])) ?? false;
  void _message(String text) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text))); }

  @override Widget build(BuildContext context) { if (_bootError != null) return Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_bootError!, textAlign: TextAlign.center)))); if (_loading || _project == null || _activeFile == null) return const Scaffold(body: Center(child: CircularProgressIndicator())); return LayoutBuilder(builder: (context, box) { final wide = box.maxWidth >= 720; return Scaffold(body: SafeArea(child: Column(children: [_topBar(wide), Expanded(child: Row(children: [if (wide) _rail(), Expanded(child: _body(wide))]))])), bottomNavigationBar: wide ? null : NavigationBar(selectedIndex: _phoneIndex, onDestinationSelected: (i) => setState(() => _destination = [AppDestination.workspace, AppDestination.terminal, AppDestination.files, AppDestination.projects, AppDestination.tools][i]), destinations: const [NavigationDestination(icon: Icon(Icons.space_dashboard_outlined), label: 'Workspace'), NavigationDestination(icon: Icon(Icons.terminal), label: 'Terminal'), NavigationDestination(icon: Icon(Icons.folder_open_outlined), label: 'Files'), NavigationDestination(icon: Icon(Icons.layers_outlined), label: 'Projects'), NavigationDestination(icon: Icon(Icons.handyman_outlined), label: 'Tools')]), floatingActionButton: !wide && _destination == AppDestination.workspace ? FloatingActionButton.small(onPressed: _palette, tooltip: 'Open command palette', child: const Icon(Icons.code)) : null); }); }
  int get _phoneIndex => switch (_destination) { AppDestination.terminal => 1, AppDestination.files => 2, AppDestination.projects => 3, AppDestination.tools => 4, _ => 0 };
  Widget _topBar(bool wide) => Container(height: 68, padding: const EdgeInsets.symmetric(horizontal: 18), decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _line))), child: Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(color: _violet.withOpacity(.18), borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.all_inclusive, color: _violet)), const SizedBox(width: 12), const Text('NEXUS LAB', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.5)), if (wide) ...[const SizedBox(width: 26), const Icon(Icons.chevron_right, size: 16, color: Colors.grey), Text(_project!.name, style: const TextStyle(color: Colors.white70)), const Spacer(), const Text('LOCAL PROJECTS', style: TextStyle(fontSize: 11, color: _cyan))], if (!wide) const Spacer(), IconButton(onPressed: _palette, tooltip: 'Search commands', icon: const Icon(Icons.search)), IconButton(onPressed: () => setState(() => _destination = AppDestination.settings), tooltip: 'Open settings', icon: const Icon(Icons.settings_outlined))]));
  Widget _rail() => Container(width: 76, decoration: const BoxDecoration(border: Border(right: BorderSide(color: _line))), child: Column(children: [const SizedBox(height: 14), _railButton(Icons.space_dashboard_outlined, 'LAB', AppDestination.workspace), _railButton(Icons.terminal, 'TERM', AppDestination.terminal), _railButton(Icons.folder_open_outlined, 'FILES', AppDestination.files), _railButton(Icons.layers_outlined, 'PROJECTS', AppDestination.projects), _railButton(Icons.handyman_outlined, 'TOOLS', AppDestination.tools), const Spacer(), _railButton(Icons.monitor_heart_outlined, 'MONITOR', AppDestination.monitor), _railButton(Icons.settings_outlined, 'SETTINGS', AppDestination.settings)]));
  Widget _railButton(IconData icon, String label, AppDestination d) => Semantics(label: label, button: true, child: InkWell(onTap: () => setState(() => _destination = d), child: Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 13), child: Column(children: [Icon(icon, color: _destination == d ? _violet : Colors.white54, size: 21), const SizedBox(height: 4), Text(label, style: TextStyle(fontSize: 9, color: _destination == d ? _violet : Colors.white38, letterSpacing: .7))]))));
  Widget _body(bool wide) => switch (_destination) { AppDestination.terminal => _terminalPanel(), AppDestination.files => Padding(padding: const EdgeInsets.all(18), child: _filesPanel()), AppDestination.projects => _projectsPanel(), AppDestination.tools => _toolsPanel(), AppDestination.monitor => _monitorPanel(), AppDestination.settings => _settingsPanel(), _ => _workspace(wide) };
  Widget _workspace(bool wide) => Padding(padding: const EdgeInsets.all(18), child: wide ? Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [SizedBox(width: 220, child: _filesPanel(compact: true)), const SizedBox(width: 14), Expanded(child: _editorPanel()), const SizedBox(width: 14), Expanded(child: _previewPanel())]) : Column(children: [Expanded(child: [_editorPanel(), _previewPanel(), _consolePanel()][_workspaceTab]), const SizedBox(height: 12), Row(children: [for (final e in {'CODE':0,'PREVIEW':1,'CONSOLE':2}.entries) Expanded(child: TextButton(onPressed: () => setState(() => _workspaceTab = e.value), child: Text(e.key, style: TextStyle(color: _workspaceTab == e.value ? _violet : Colors.white54))))])]);
  Widget _card(Widget child, {EdgeInsets padding = const EdgeInsets.all(16)}) => Container(padding: padding, decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: _line)), child: child);
  Widget _filesPanel({bool compact = false}) { final query = _search.text.toLowerCase(); final files = _project!.files.where((f) => f.path.toLowerCase().contains(query)).toList(); return _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_header('PROJECT FILES', IconButton(onPressed: _newFile, tooltip: 'Create file', icon: const Icon(Icons.add, size: 18))), TextField(controller: _search, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Icon(Icons.search, size: 17), hintText: 'Search files')), const SizedBox(height: 12), Expanded(child: files.isEmpty ? Center(child: Text('No files match \'${_search.text}\'')) : ListView(children: files.map((f) => ListTile(selected: f == _activeFile, selectedTileColor: _violet.withOpacity(.12), onTap: () => _selectFile(f), onLongPress: () => _fileMenu(f), leading: Icon(_fileIcon(f), color: _fileColor(f)), title: Text(f.name), trailing: f == _activeFile && _dirty ? const Icon(Icons.circle, size: 7, color: _cyan) : null)).toList())), if (!compact) OutlinedButton.icon(onPressed: _newFile, icon: const Icon(Icons.add), label: const Text('NEW FILE'))])); }
  Widget _header(String text, Widget action) => Row(children: [Text(text, style: const TextStyle(fontSize: 11, letterSpacing: 1.3, color: Colors.white60, fontWeight: FontWeight.bold)), const Spacer(), action]);
  IconData _fileIcon(ProjectFile f) => f.extension == 'html' ? Icons.language : f.extension == 'css' ? Icons.brush_outlined : f.extension == 'js' ? Icons.javascript : Icons.description_outlined;
  Color _fileColor(ProjectFile f) => f.extension == 'html' ? Colors.orange : f.extension == 'css' ? _cyan : f.extension == 'js' ? Colors.amber : Colors.white54;
  Widget _editorPanel() { final file = _activeFile!; return _card(Column(children: [Row(children: [Text(file.name, style: const TextStyle(color: Colors.white70)), if (_dirty) const Padding(padding: EdgeInsets.only(left: 7), child: Icon(Icons.circle, size: 7, color: _cyan)), const Spacer(), IconButton(onPressed: _save, tooltip: 'Save project', icon: const Icon(Icons.save_outlined)), IconButton(onPressed: _run, tooltip: 'Run project', icon: const Icon(Icons.play_arrow_rounded, color: _cyan))]), const Divider(height: 1, color: _line), Expanded(child: TextField(controller: _controllerFor(file), maxLines: null, expands: true, textAlignVertical: TextAlignVertical.top, style: TextStyle(fontFamily: 'monospace', fontSize: _fontSize.toDouble(), height: 1.5), decoration: const InputDecoration(contentPadding: EdgeInsets.all(14), border: InputBorder.none, hintText: 'Start building...')))]), padding: EdgeInsets.zero); }
  Widget _previewPanel() => _card(Column(children: [_header('LIVE PREVIEW', IconButton(onPressed: _run, tooltip: 'Reload preview', icon: const Icon(Icons.refresh, size: 18))), const Divider(height: 1, color: _line), Expanded(child: PreviewFrame(project: _project!, revision: _previewRevision, onLog: (m) => setState(() { _console.insert(0, m); if (_console.length > 200) _console.removeLast(); })))]), padding: EdgeInsets.zero);
  Widget _consolePanel() => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_header('CONSOLE', IconButton(onPressed: () => setState(_console.clear), tooltip: 'Clear console', icon: const Icon(Icons.delete_outline))), const SizedBox(height: 8), Expanded(child: _console.isEmpty ? const Center(child: Text('Run the project to inspect console output.', style: TextStyle(color: Colors.white38))) : ListView(children: _console.take(200).map((x) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Text(x, style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: x.contains('ERROR') ? Colors.redAccent : x.contains('WARN') ? Colors.amber : Colors.white70))).toList()))]));
  Widget _terminalPanel() => Padding(padding: const EdgeInsets.all(18), child: _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_header('TERMINAL', const Text('PROVIDER OFFLINE', style: TextStyle(color: Colors.amber, fontSize: 11))), const SizedBox(height: 10), const Text('Terminal provider unavailable. Editing and web preview remain available; connect an ExecutionProvider to run system commands.', style: TextStyle(color: Colors.white54)), const SizedBox(height: 12), Expanded(child: ListView(children: _terminal.map((x) => Text(x, style: const TextStyle(fontFamily: 'monospace', color: Colors.white70))).toList())), const Divider(color: _line), Row(children: [Expanded(child: TextField(controller: _command, enabled: false, readOnly: true, decoration: const InputDecoration(hintText: 'Execution provider unavailable', border: InputBorder.none))), IconButton(onPressed: null, tooltip: 'Terminal provider unavailable', icon: const Icon(Icons.lock_outline, color: Colors.white38))])])));
  void _submitCommand() { _message('Terminal provider unavailable.'); }
  Widget _projectsPanel() => Padding(padding: const EdgeInsets.all(18), child: FutureBuilder<List<Project>>(future: _repo.listProjects(), builder: (context, snap) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('PROJECTS', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)), const SizedBox(height: 6), const Text('Persistent local workspaces', style: TextStyle(color: Colors.white54)), const SizedBox(height: 18), Expanded(child: ListView(children: [...(snap.data ?? []).map((p) => Padding(padding: const EdgeInsets.only(bottom: 10), child: _card(ListTile(title: Text(p.name), subtitle: Text('${p.fileCount} files · ${p.templateType}'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [FilledButton(onPressed: () => _switchProject(p), child: const Text('OPEN')), PopupMenuButton<String>(onSelected: (action) { if (action == 'rename') _renameProject(p); if (action == 'duplicate') _duplicateProject(p); if (action == 'delete') _deleteProject(p); }, itemBuilder: (_) => const [PopupMenuItem(value: 'rename', child: Text('Rename')), PopupMenuItem(value: 'duplicate', child: Text('Duplicate')), PopupMenuItem(value: 'delete', child: Text('Delete'))])]))))), _card(InkWell(onTap: _newProject, child: const Center(child: Padding(padding: EdgeInsets.all(12), child: Text('+ CREATE NEW PROJECT', style: TextStyle(color: _cyan, fontWeight: FontWeight.bold))))))]))]));
  Widget _toolsPanel() => Padding(padding: const EdgeInsets.all(18), child: ListView(children: [Text('TOOLS LAB', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)), const SizedBox(height: 6), const Text('Offline utilities that do real work', style: TextStyle(color: Colors.white54)), const SizedBox(height: 18), for (final tool in ['JSON Formatter','Base64 Encoder / Decoder','UUID Generator','URL Encoder / Decoder']) Padding(padding: const EdgeInsets.only(bottom: 10), child: _card(ListTile(title: Text(tool), subtitle: const Text('Available locally', style: TextStyle(color: _cyan)), onTap: () => _toolDialog(tool))))]));
  void _toolDialog(String tool) {
    final input = TextEditingController();
    String output = '';
    String mode = tool.startsWith('Base64') || tool.startsWith('URL') ? 'Encode' : 'Format';
    showDialog(context: context, builder: (_) => StatefulBuilder(builder: (context, update) => AlertDialog(
      title: Text(tool),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        if (tool.startsWith('Base64') || tool.startsWith('URL')) DropdownButton<String>(value: mode, items: const [DropdownMenuItem(value: 'Encode', child: Text('Encode')), DropdownMenuItem(value: 'Decode', child: Text('Decode'))], onChanged: (v) => update(() => mode = v ?? 'Encode')),
        TextField(controller: input, maxLines: 5, decoration: const InputDecoration(hintText: 'Input')),
        if (output.isNotEmpty) SelectableText(output),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('CLOSE')),
        FilledButton(onPressed: () { try { if (tool.startsWith('JSON')) { output = const JsonEncoder.withIndent('  ').convert(jsonDecode(input.text)); } else if (tool.startsWith('URL')) { output = mode == 'Encode' ? Uri.encodeComponent(input.text) : Uri.decodeComponent(input.text); } else if (tool.startsWith('Base64')) { output = mode == 'Encode' ? base64Encode(utf8.encode(input.text)) : utf8.decode(base64Decode(input.text)); } else { final r = Random.secure(); output = '${r.nextInt(1 << 32).toRadixString(16).padLeft(8, '0')}-${r.nextInt(1 << 16).toRadixString(16).padLeft(4, '0')}-4${r.nextInt(1 << 12).toRadixString(16).padLeft(3, '0')}-${(8 + r.nextInt(4)).toRadixString(16)}${r.nextInt(1 << 12).toRadixString(16).padLeft(3, '0')}-${r.nextInt(1 << 48).toRadixString(16).padLeft(12, '0')}'; } update(() {}); } catch (e) { update(() => output = 'Error: $e'); } }, child: const Text('PROCESS')),
      ],
    )));
  }
  Widget _monitorPanel() => Padding(padding: const EdgeInsets.all(18), child: ListView(children: [Text('SYSTEM MONITOR', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)), const SizedBox(height: 8), const Text('Metric unavailable on this device/build.', style: TextStyle(color: Colors.amber)), const SizedBox(height: 20), _card(const ListTile(leading: Icon(Icons.memory), title: Text('CPU / RAM / STORAGE'), subtitle: Text('No native telemetry provider is connected.')))]));
  Widget _settingsPanel() {
    final app = _project!.appConfig;
    return Padding(padding: const EdgeInsets.all(18), child: ListView(children: [
      Text('SETTINGS', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 18),
      _card(Column(children: [
        const Align(alignment: Alignment.centerLeft, child: Text('APP CONFIGURATION', style: TextStyle(color: _violet, fontWeight: FontWeight.bold))),
        TextField(controller: _appNameController, decoration: const InputDecoration(labelText: 'App name'), onChanged: (v) { app.appName = v; _dirty = true; _scheduleAutosave(); }),
        TextField(controller: _packageController, decoration: const InputDecoration(labelText: 'Package ID'), onChanged: (v) { app.packageId = v; _dirty = true; _scheduleAutosave(); }),
        TextField(decoration: InputDecoration(labelText: 'Icon path', hintText: app.iconPath ?? 'assets/icon.png'), onChanged: (v) { app.iconPath = v.trim().isEmpty ? null : v.trim(); _dirty = true; _scheduleAutosave(); }),
        TextField(decoration: InputDecoration(labelText: 'Splash logo path', hintText: app.splashPath ?? 'assets/splash.png'), onChanged: (v) { app.splashPath = v.trim().isEmpty ? null : v.trim(); _dirty = true; _scheduleAutosave(); }),
        DropdownButtonFormField<String>(value: app.splashAnimation, decoration: const InputDecoration(labelText: 'Splash animation'), items: const [DropdownMenuItem(value: 'none', child: Text('None')), DropdownMenuItem(value: 'fade', child: Text('Fade')), DropdownMenuItem(value: 'scale', child: Text('Scale'))], onChanged: (v) { if (v != null) { app.splashAnimation = v; _dirty = true; _scheduleAutosave(); } }),
        DropdownButtonFormField<String>(value: app.orientation, decoration: const InputDecoration(labelText: 'Orientation'), items: const [DropdownMenuItem(value: 'portrait', child: Text('Portrait')), DropdownMenuItem(value: 'landscape', child: Text('Landscape')), DropdownMenuItem(value: 'any', child: Text('Any orientation'))], onChanged: (v) { if (v != null) { app.orientation = v; _dirty = true; _scheduleAutosave(); } }),
        SwitchListTile(title: const Text('Fullscreen'), value: app.fullscreen, onChanged: (v) { setState(() => app.fullscreen = v); _dirty = true; _scheduleAutosave(); }),
        SwitchListTile(title: const Text('Status bar'), value: app.statusBar, onChanged: (v) { setState(() => app.statusBar = v); _dirty = true; _scheduleAutosave(); }),
        SwitchListTile(title: const Text('Navigation bar'), value: app.navigationBar, onChanged: (v) { setState(() => app.navigationBar = v); _dirty = true; _scheduleAutosave(); }),
        TextField(decoration: InputDecoration(labelText: 'Permissions', hintText: app.permissions.join(', ')), onChanged: (v) { app.permissions = v.split(',').map((x) => x.trim()).where((x) => x.isNotEmpty).toList(); _dirty = true; _scheduleAutosave(); }),
        Align(alignment: Alignment.centerRight, child: FilledButton(onPressed: () async { await _save(); _buildApk(); }, child: const Text('BUILD APK'))),
      ])),
      const SizedBox(height: 12),
      _card(Column(children: [
        const Align(alignment: Alignment.centerLeft, child: Text('EDITOR / PREVIEW', style: TextStyle(color: _violet, fontWeight: FontWeight.bold))),
        DropdownButtonFormField<int>(value: _fontSize, items: [11,12,13,14,16,18].map((x) => DropdownMenuItem(value: x, child: Text('$x px'))).toList(), onChanged: (v) async { if (v == null) return; await _settings.setFontSize(v); setState(() => _fontSize = v); }),
        SwitchListTile(title: const Text('Debounced autosave'), subtitle: const Text('Saves 700ms after editing stops'), value: _autoSave, onChanged: (v) async { await _settings.setAutoSave(v); setState(() => _autoSave = v); }),
        SwitchListTile(title: const Text('Auto-run after save'), subtitle: const Text('Reloads preview after a debounce'), value: _autoRun, onChanged: (v) async { await _settings.setAutoRun(v); setState(() => _autoRun = v); }),
      ])),
      const SizedBox(height: 12),
      _card(const ListTile(title: Text('Terminal provider'), subtitle: Text('Unavailable · terminal is locked and no commands are faked', style: TextStyle(color: Colors.amber)), trailing: Icon(Icons.lock_outline))),
    ]));
  }
  void _fileMenu(ProjectFile file) => showModalBottomSheet(context: context, backgroundColor: _panel, builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [ListTile(title: const Text('Rename'), onTap: () { Navigator.pop(context); _renameFile(file); }), ListTile(title: const Text('Delete'), onTap: () { Navigator.pop(context); _deleteFile(file); })])));
  void _palette() => showModalBottomSheet(context: context, backgroundColor: _panel, builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [for (final item in {'Save': _save, 'Run': _run, 'Create File': _newFile, 'Create Project': _newProject, 'Build APK': _buildApk, 'Open Settings': () async => setState(() => _destination = AppDestination.settings)}.entries) ListTile(title: Text(item.key), onTap: () { Navigator.pop(context); item.value(); })])));
}

class PreviewFrame extends StatefulWidget {
  const PreviewFrame({super.key, required this.project, required this.revision, required this.onLog});
  final Project project;
  final int revision;
  final ValueChanged<String> onLog;
  @override State<PreviewFrame> createState() => _PreviewFrameState();
}

class _PreviewFrameState extends State<PreviewFrame> {
  late final WebViewController _controller;
  PreviewState _state = PreviewState.idle;
  String? _error;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('NexusConsole', onMessageReceived: (m) => widget.onLog(m.message))
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) => _setState(PreviewState.loading),
        onPageFinished: (_) => _setState(PreviewState.ready),
        onWebResourceError: (e) { _error = e.description; _setState(PreviewState.error); },
      ));
    _load();
  }

  @override
  void didUpdateWidget(covariant PreviewFrame oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.revision != oldWidget.revision) _load();
  }

  void _setState(PreviewState state) { if (mounted) setState(() => _state = state); }

  void _load() {
    final bundle = ProjectBundleResolver().resolve(widget.project);
    if (bundle == null) { _error = 'Entry file not found. Choose an HTML entry file.'; _setState(PreviewState.error); return; }
    _error = null;
    _setState(PreviewState.loading);
    const bridge = r'''<script>(function(){function stringify(v){try{if(typeof v==='string')return v;return JSON.stringify(v,function(k,x){if(typeof x==='bigint')return x.toString()+'n';if(x instanceof Error)return {name:x.name,message:x.message,stack:x.stack};return x;})}catch(e){return String(v)}}function send(level,args){NexusConsole.postMessage(level+'  '+args.map(stringify).join(' '));}['log','info','warn','error'].forEach(function(level){var original=console[level];console[level]=function(){send(level.toUpperCase(),Array.from(arguments));original.apply(console,arguments);};});window.onerror=function(message,source,line,column){send('ERROR',[message,source?source+':'+line+':'+column:'']);};window.addEventListener('unhandledrejection',function(event){send('ERROR',['Unhandled promise rejection',event.reason]);});})();</script>''';
    final html = '<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">$bridge</head><body>${bundle.html}</body></html>';
    _controller.loadHtmlString(html);
  }

  @override
  Widget build(BuildContext context) => Stack(children: [
    WebViewWidget(controller: _controller),
    if (_state == PreviewState.loading) const Center(child: CircularProgressIndicator()),
    if (_state == PreviewState.error) Center(child: Container(color: _panel, padding: const EdgeInsets.all(16), child: Text(_error ?? 'Preview failed', textAlign: TextAlign.center, style: const TextStyle(color: Colors.amber)))),
  ]);
}
