abstract class AIProvider {
  String get status;
  Future<String> ask({required String action, required String projectContext});
}

class UnavailableAIProvider implements AIProvider {
  @override
  String get status => 'NOT CONNECTED';

  @override
  Future<String> ask({required String action, required String projectContext}) async =>
      'AI provider unavailable. Connect a provider before requesting $action.';
}
