import 'package:flutter_test/flutter_test.dart';
import 'package:nexus_lab/main.dart';

void main() {
  testWidgets('NEXUS LAB opens the workspace', (tester) async {
    await tester.pumpWidget(const NexusLabApp());
    await tester.pumpAndSettle();
    expect(find.text('NEXUS LAB'), findsOneWidget);
    expect(find.text('index.html'), findsOneWidget);
  });
}
