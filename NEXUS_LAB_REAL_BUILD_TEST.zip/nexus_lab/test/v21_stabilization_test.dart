import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:nexus_lab/build/build_engine.dart';
import 'package:nexus_lab/models/project.dart';
import 'package:nexus_lab/services/console_service.dart';
import 'package:nexus_lab/services/project_bundle.dart';
import 'package:nexus_lab/services/project_templates.dart';
import 'package:nexus_lab/services/project_repository.dart';

class MemoryProjectStorage extends ProjectStorage {
  Map<String, Project> values = {};
  @override
  Future<Map<String, Project>> read() async => values;
  @override
  Future<void> write(Map<String, Project> projects) async => values = Map.of(projects);
}

void main() {
  test('relative CSS, JS, and image assets are resolved from nested entry files', () {
    final project = Project(id: 'p', name: 'nested', files: [
      ProjectFile(path: 'pages/index.html', content: '<link href="../style.css"><script src="../script.js"></script><img src="../assets/logo.svg">'),
      ProjectFile(path: 'style.css', content: 'body{color:red}'),
      ProjectFile(path: 'script.js', content: 'console.log({ok:true})'),
      ProjectFile(path: 'assets/logo.svg', content: '<svg></svg>'),
    ], entryFile: 'pages/index.html');
    final bundle = ProjectBundleResolver().resolve(project)!;
    expect(bundle.html, contains('<style data-nexus-source="style.css">body{color:red}</style>'));
    expect(bundle.html, contains('<script data-nexus-source="script.js">console.log({ok:true})</script>'));
    expect(bundle.html, contains('data:image/svg+xml;base64,'));
  });

  test('AppConfig persists V2.1 customization fields', () {
    final config = AppConfig(appName: 'Demo', packageId: 'com.example.demo', iconPath: 'icon.png', splashPath: 'splash.png', splashAnimation: 'fade', orientation: 'landscape', fullscreen: true, statusBar: false, navigationBar: false, permissions: ['INTERNET']);
    final restored = AppConfig.fromJson(config.toJson());
    expect(restored.toJson(), config.toJson());
  });

  test('console service is typed, bounded, and clearable', () {
    final console = ConsoleService(maxEntries: 2);
    console.add(const ConsoleEntry(level: ConsoleLevel.log, message: 'one'));
    console.add(const ConsoleEntry(level: ConsoleLevel.warn, message: 'two'));
    console.add(const ConsoleEntry(level: ConsoleLevel.error, message: 'three'));
    expect(console.entries.map((e) => e.message), ['two', 'three']);
    console.clear();
    expect(console.entries, isEmpty);
  });

  test('preflight exposes individual checks and blocks unsupported or invalid builds', () {
    final project = ProjectTemplates.create('html');
    project.appConfig.packageId = 'bad package';
    final report = BuildPreflight.inspect(project, target: 'flutterProject');
    expect(report.canBuild, isFalse);
    expect(report.failures.map((c) => c.label), containsAll(['Package ID valid', 'Target supported']));
  });

  test('Base64 and URL encode/decode round trip using the same primitives as the tool', () {
    const value = 'NEXUS lab / ✓';
    expect(utf8.decode(base64Decode(base64Encode(utf8.encode(value)))), value);
    expect(Uri.decodeComponent(Uri.encodeComponent(value)), value);
  });

  test('repository supports create, open, rename, duplicate, delete, and switch', () async {
    final repository = ProjectRepository(MemoryProjectStorage());
    final first = ProjectTemplates.create('html', name: 'first');
    await repository.createProject(first);
    expect((await repository.loadProject(first.id))?.name, 'first');
    await repository.renameProject(first, 'renamed');
    final copy = await repository.duplicateProject(first);
    expect(copy.name, 'renamed copy');
    expect((await repository.listProjects()).length, 2);
    await repository.deleteProject(first.id);
    expect((await repository.listProjects()).single.id, copy.id);
  });
}
