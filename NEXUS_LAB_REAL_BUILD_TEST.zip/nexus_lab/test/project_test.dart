import 'package:flutter_test/flutter_test.dart';
import 'package:nexus_lab/build/build_engine.dart';
import 'package:nexus_lab/models/project.dart';
import 'package:nexus_lab/services/project_templates.dart';

void main() {
  test('HTML starter creates the expected editable files', () {
    final project = ProjectTemplates.create('html', name: 'demo');
    expect(project.name, 'demo');
    expect(project.files.map((file) => file.path), containsAll(<String>['index.html', 'style.css', 'script.js']));
    expect(project.entryFile, 'index.html');
  });

  test('project and nested files round-trip through JSON', () {
    final original = ProjectTemplates.create('multi-page', name: 'round-trip');
    original.appConfig.packageId = 'com.example.roundtrip';
    final restored = Project.fromJson(original.toJson());
    expect(restored.name, original.name);
    expect(restored.files.length, original.files.length);
    expect(restored.appConfig.packageId, 'com.example.roundtrip');
  });

  test('build preflight rejects invalid package IDs and missing entries', () {
    final project = ProjectTemplates.create('blank');
    project.entryFile = 'missing.html';
    project.appConfig.packageId = 'not valid';
    final errors = BuildPreflight.validate(project);
    expect(errors, contains('Entry HTML exists: Entry file "missing.html" does not exist.'));
    expect(errors, contains('Package ID valid: Package ID needs at least two segments, for example com.example.myapp.'));
  });

  test('file rename and delete operations are regular model operations', () {
    final project = ProjectTemplates.create('html');
    final file = project.files.first;
    file.path = 'home.html';
    project.files.remove(file);
    expect(project.fileAt('home.html'), isNull);
  });
}
